package cs.tcd.ie;

import java.net.DatagramSocket;
import java.net.DatagramPacket;
import java.net.InetSocketAddress;

import tcdIO.*;

public class Gateway extends Node 
{
	static final int DEFAULT_GATEWAY_PORT = 12345;
	
	Terminal terminal;
	static int dst_port;
	InetSocketAddress dstAddress;
	
	Gateway(Terminal terminal, int srcPort) 
	{
		try {
			this.terminal = terminal;
			socket = new DatagramSocket(srcPort);
			listener.go();
		} catch (java.lang.Exception e) {
			e.printStackTrace();
		}
	}
	
	public void onReceipt(DatagramPacket packet) {
		try {
			StringContent content = new StringContent(packet);
			terminal.println("Packet received.");
			byte[] buffer = new byte[packet.getLength()];
			System.arraycopy(packet.getData(), 0, buffer, 0, buffer.length);
			if(buffer[7] == 1)
				buffer = content.string.getBytes();
			
			int dstPort = 0;
			if(buffer[5]<0)
				dstPort += ((int)buffer[5]&0xff)*256;
			else
				dstPort += (int)buffer[5]*256;
			if(buffer[6]<0)
				dstPort += (int)buffer[6]&0xff;
			else
				dstPort += (int)buffer[6];
			InetSocketAddress dstAddress = new InetSocketAddress(Client.DEFAULT_DST_NODE, dstPort);
			DatagramPacket new_packet = new DatagramPacket(buffer, buffer.length, dstAddress);
			socket.send(new_packet);
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public synchronized void start() throws Exception {
		terminal.println("Waiting for contact");
		this.wait();
	}
	public static void main(String[] args)
	{
		try {
			Terminal terminal = new Terminal("Gateway");
			(new Gateway(terminal, DEFAULT_GATEWAY_PORT)).start();
		} catch (java.lang.Exception e) {
			e.printStackTrace();
		}
	}
}