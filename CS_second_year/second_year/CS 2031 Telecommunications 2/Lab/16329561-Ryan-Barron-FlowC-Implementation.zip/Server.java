package cs.tcd.ie;

import java.net.DatagramPacket;
import java.net.DatagramSocket;

import tcdIO.Terminal;

public class Server extends Node {
	static final int DEFAULT_PORT = 50001;

	Terminal terminal;
	int sequenceExpected;
	/*
	 * 
	 */
	Server(Terminal terminal, int port) {
		try {
			this.terminal = terminal;
			this.sequenceExpected = 1;
			socket = new DatagramSocket(port);
			listener.go();
		} catch (java.lang.Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Assume that incoming packets contain a String and print the string.
	 */
	public void onReceipt(DatagramPacket packet) {
		try {
			
			StringContent content = new StringContent(packet);
			terminal.println(content.toString());
			byte[] buffer;
			buffer = packet.getData();
			byte[] header = new byte[PacketContent.HEADERLENGTH];
			header[0] = buffer[5];
			header[1] = buffer[6];
			header[5] = buffer[0];
			header[6] = buffer[1];
			
			int srcPort = 0;
			if(buffer[0]<0)
				srcPort += ((int)buffer[0]&0xff)*256;
			else
				srcPort += (int)buffer[0]*256;
			if(buffer[1]<0)
				srcPort += (int)buffer[1]&0xff;
			else
				srcPort += (int)buffer[1];
			
			
			if(sequenceExpected == buffer[9])
			{
				sequenceExpected++;
				header[9] = (byte)(buffer[9]+1);
				byte[] payload;
				payload = (new String("ACK " + header[9])).getBytes();
				byte[] buf = new byte[header.length + payload.length];
				System.arraycopy(header, 0, buf, 0, header.length);
				System.arraycopy(payload, 0, buf, header.length, payload.length);
				DatagramPacket response;
				response = new DatagramPacket(buf, buf.length);
				response.setSocketAddress(packet.getSocketAddress());
				socket.send(response);
			}
			else
			{
				header[9] = buffer[9];
				header[8] = 1;
				byte[] payload;
				payload = (new String("NACK " + header[9])).getBytes();
				byte[] buf = new byte[header.length + payload.length];
				System.arraycopy(header, 0, buf, 0, header.length);
				System.arraycopy(payload, 0, buf, header.length, payload.length);
				DatagramPacket response;
				response = new DatagramPacket(buf, buf.length);
				response.setSocketAddress(packet.getSocketAddress());
				socket.send(response);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public synchronized void start() throws Exception {
		terminal.println("Waiting for contact");
		this.wait();
	}

	/*
	 * 
	 */
	public static void main(String[] args) {
		try {
			Terminal terminal = new Terminal("Server");
			(new Server(terminal, DEFAULT_PORT)).start();
			terminal.println("Program completed");
		} catch (java.lang.Exception e) {
			e.printStackTrace();
		}
	}
}
