/**
 * 
 */
package cs.tcd.ie;

import java.net.DatagramSocket;
import java.net.DatagramPacket;
import java.net.InetSocketAddress;

import tcdIO.*;

/**
 *
 * Client class
 * 
 * An instance accepts user input
 *
 */
public class Client extends Node {
	static final int DEFAULT_SRC_PORT = 50000;
	static final int DEFAULT_DST_PORT = 50001;
	static final int DEFAULT_GATEWAY_PORT = 12345;
	static final String DEFAULT_DST_NODE = "localhost";

	Terminal terminal;
	InetSocketAddress dstAddress;
	int sequenceNumber;
	int portNumber;
	/**
	 * Constructor
	 * 
	 * Attempts to create socket at given port and create an InetSocketAddress
	 * for the destinations
	 */
	Client(Terminal terminal, String dstHost, int dstPort, int srcPort) 
	{
		try {
			this.terminal = terminal;
			this.portNumber = srcPort;
			sequenceNumber = 1;
			dstAddress = new InetSocketAddress(dstHost, dstPort);
			socket = new DatagramSocket(srcPort);
			listener.go();
		} catch (java.lang.Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Assume that incoming packets contain a String and print the string.
	 */
	public synchronized void onReceipt(DatagramPacket packet)
	{
		byte[] buf;
		buf = packet.getData();
		if(buf[8] == 1)
			this.sequenceNumber = buf[9];
		else
			this.sequenceNumber++;
		StringContent content = new StringContent(packet);
		this.notify();
		terminal.println(content.toString());
	}

	/**
	 * Sender Method
	 * 
	 */
	public synchronized void start() throws Exception 
	{
		/*			Creating packet for server		*/
		DatagramPacket packet = null;
		byte[] payload = null;
		byte[] header = null;
		byte[] buffer = null;
		payload = (terminal.readString("String to send: ")).getBytes();
		header = new byte[PacketContent.HEADERLENGTH];
		header[0] = (byte)(this.portNumber/256);				
		header[1] = (byte)(this.portNumber%256);
		header[5] = (byte)(DEFAULT_DST_PORT/256);				
		header[6] = (byte)(DEFAULT_DST_PORT%256);
		header[9] = (byte)this.sequenceNumber;		
		buffer = new byte[header.length + payload.length];
		System.arraycopy(header, 0, buffer, 0, header.length);
		System.arraycopy(payload, 0, buffer, header.length, payload.length);
		terminal.println("Sending packet...");
		packet = new DatagramPacket(buffer, buffer.length, dstAddress);
		
		/*			Creating packet for gateway with packet for server inside		*/
		dstAddress = new InetSocketAddress(DEFAULT_DST_NODE, DEFAULT_GATEWAY_PORT);
		DatagramPacket packet_gateway = null;
		byte[] payload_gateway = null;
		byte[] header_gateway = new byte[PacketContent.HEADERLENGTH];
		byte[] buffer_gateway = null;
		payload_gateway = packet.getData();
		header_gateway[0] = (byte)(this.portNumber/256);
		header_gateway[1] = (byte)(this.portNumber%256);
		header_gateway[5] = (byte)(DEFAULT_GATEWAY_PORT/256);
		header_gateway[6] = (byte)(DEFAULT_GATEWAY_PORT%256);
		header_gateway[7] = 1;									// contains another packet inside = true
		buffer_gateway = new byte[header_gateway.length + payload_gateway.length];
		System.arraycopy(header_gateway, 0, buffer_gateway, 0, header_gateway.length);
		System.arraycopy(payload_gateway, 0, buffer_gateway, header_gateway.length, payload_gateway.length);
		packet_gateway = new DatagramPacket(buffer_gateway, buffer_gateway.length, dstAddress);
		
		socket.send(packet_gateway);
		terminal.println("Packet sent");
		this.wait();
	}	
		

	/**
	 * Test method
	 * 
	 * Sends a packet to a given address
	 */
	public static void main(String[] args) 
	{
		try {
			Terminal terminal0 = new Terminal("Client0");
			//Terminal terminal1 = new Terminal("Client1");
			//Terminal terminal2 = new Terminal("Client2");
			boolean keepRunning = true;
			
			Client client0 = new Client(terminal0, DEFAULT_DST_NODE, DEFAULT_DST_PORT, DEFAULT_SRC_PORT);
			//Client client1 = new Client(terminal1, DEFAULT_DST_NODE, DEFAULT_DST_PORT, DEFAULT_SRC_PORT-1);
			//Client client2 = new Client(terminal2, DEFAULT_DST_NODE, DEFAULT_DST_PORT, DEFAULT_SRC_PORT-2);
			while(keepRunning){
				client0.start();
				//client1.start();
				//client2.start();
			}
			terminal0.println("Program completed");
		} catch (java.lang.Exception e) {
			e.printStackTrace();
		}
	}
}
